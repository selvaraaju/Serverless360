import logo from './Call_for_Code_logo.png';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo}  alt="Call for Code" />
        <p>
          Welcome to Call for Code Sample Project!
        </p>
      </header>
    </div>
  );
}

export default App;
